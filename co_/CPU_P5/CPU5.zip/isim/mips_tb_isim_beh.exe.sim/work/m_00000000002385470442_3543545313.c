/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/hp/Desktop/CPU_P5/CPU5/WREG.v";
static unsigned int ng1[] = {3U, 3U};
static int ng2[] = {0, 0};
static int ng3[] = {1, 0};



static void Always_39_0(char *t0)
{
    char t6[8];
    char t7[8];
    char t8[8];
    char t38[8];
    char t39[8];
    char t42[8];
    char t59[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    char *t21;
    char *t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    char *t28;
    char *t29;
    unsigned int t30;
    unsigned int t31;
    unsigned int t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t40;
    char *t41;
    char *t43;
    char *t44;
    char *t45;
    char *t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    unsigned int t51;
    char *t52;
    char *t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    char *t58;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    char *t64;
    char *t65;

LAB0:    t1 = (t0 + 4128U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(39, ng0);
    t2 = (t0 + 4448);
    *((int *)t2) = 1;
    t3 = (t0 + 4160);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(39, ng0);

LAB5:    xsi_set_current_line(40, ng0);
    t4 = (t0 + 1208U);
    t5 = *((char **)t4);
    t4 = (t0 + 2408);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 32, 0LL);
    xsi_set_current_line(41, ng0);
    t2 = (t0 + 1368U);
    t3 = *((char **)t2);
    t2 = (t0 + 2568);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(42, ng0);
    t2 = (t0 + 1528U);
    t3 = *((char **)t2);
    t2 = (t0 + 2728);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(43, ng0);
    t2 = (t0 + 1688U);
    t3 = *((char **)t2);
    t2 = (t0 + 2888);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 5, 0LL);
    xsi_set_current_line(44, ng0);
    t2 = (t0 + 1848U);
    t3 = *((char **)t2);
    t2 = (t0 + 3048);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 32, 0LL);
    xsi_set_current_line(45, ng0);
    t2 = (t0 + 2008U);
    t3 = *((char **)t2);
    t2 = ((char*)((ng1)));
    memset(t8, 0, 8);
    t4 = (t3 + 4);
    t5 = (t2 + 4);
    t9 = *((unsigned int *)t3);
    t10 = *((unsigned int *)t2);
    t11 = (t9 ^ t10);
    t12 = *((unsigned int *)t4);
    t13 = *((unsigned int *)t5);
    t14 = (t12 ^ t13);
    t15 = (t11 | t14);
    t16 = *((unsigned int *)t4);
    t17 = *((unsigned int *)t5);
    t18 = (t16 | t17);
    t19 = (~(t18));
    t20 = (t15 & t19);
    if (t20 != 0)
        goto LAB9;

LAB6:    if (t18 != 0)
        goto LAB8;

LAB7:    *((unsigned int *)t8) = 1;

LAB9:    memset(t7, 0, 8);
    t22 = (t8 + 4);
    t23 = *((unsigned int *)t22);
    t24 = (~(t23));
    t25 = *((unsigned int *)t8);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB10;

LAB11:    if (*((unsigned int *)t22) != 0)
        goto LAB12;

LAB13:    t29 = (t7 + 4);
    t30 = *((unsigned int *)t7);
    t31 = *((unsigned int *)t29);
    t32 = (t30 || t31);
    if (t32 > 0)
        goto LAB14;

LAB15:    t34 = *((unsigned int *)t7);
    t35 = (~(t34));
    t36 = *((unsigned int *)t29);
    t37 = (t35 || t36);
    if (t37 > 0)
        goto LAB16;

LAB17:    if (*((unsigned int *)t29) > 0)
        goto LAB18;

LAB19:    if (*((unsigned int *)t7) > 0)
        goto LAB20;

LAB21:    memcpy(t6, t38, 8);

LAB22:    t65 = (t0 + 3208);
    xsi_vlogvar_wait_assign_value(t65, t6, 0, 0, 2, 0LL);
    goto LAB2;

LAB8:    t21 = (t8 + 4);
    *((unsigned int *)t8) = 1;
    *((unsigned int *)t21) = 1;
    goto LAB9;

LAB10:    *((unsigned int *)t7) = 1;
    goto LAB13;

LAB12:    t28 = (t7 + 4);
    *((unsigned int *)t7) = 1;
    *((unsigned int *)t28) = 1;
    goto LAB13;

LAB14:    t33 = ((char*)((ng1)));
    goto LAB15;

LAB16:    t40 = (t0 + 2008U);
    t41 = *((char **)t40);
    t40 = ((char*)((ng2)));
    memset(t42, 0, 8);
    t43 = (t41 + 4);
    if (*((unsigned int *)t43) != 0)
        goto LAB24;

LAB23:    t44 = (t40 + 4);
    if (*((unsigned int *)t44) != 0)
        goto LAB24;

LAB27:    if (*((unsigned int *)t41) > *((unsigned int *)t40))
        goto LAB25;

LAB26:    memset(t39, 0, 8);
    t46 = (t42 + 4);
    t47 = *((unsigned int *)t46);
    t48 = (~(t47));
    t49 = *((unsigned int *)t42);
    t50 = (t49 & t48);
    t51 = (t50 & 1U);
    if (t51 != 0)
        goto LAB28;

LAB29:    if (*((unsigned int *)t46) != 0)
        goto LAB30;

LAB31:    t53 = (t39 + 4);
    t54 = *((unsigned int *)t39);
    t55 = *((unsigned int *)t53);
    t56 = (t54 || t55);
    if (t56 > 0)
        goto LAB32;

LAB33:    t60 = *((unsigned int *)t39);
    t61 = (~(t60));
    t62 = *((unsigned int *)t53);
    t63 = (t61 || t62);
    if (t63 > 0)
        goto LAB34;

LAB35:    if (*((unsigned int *)t53) > 0)
        goto LAB36;

LAB37:    if (*((unsigned int *)t39) > 0)
        goto LAB38;

LAB39:    memcpy(t38, t64, 8);

LAB40:    goto LAB17;

LAB18:    xsi_vlog_unsigned_bit_combine(t6, 32, t33, 32, t38, 32);
    goto LAB22;

LAB20:    memcpy(t6, t33, 8);
    goto LAB22;

LAB24:    t45 = (t42 + 4);
    *((unsigned int *)t42) = 1;
    *((unsigned int *)t45) = 1;
    goto LAB26;

LAB25:    *((unsigned int *)t42) = 1;
    goto LAB26;

LAB28:    *((unsigned int *)t39) = 1;
    goto LAB31;

LAB30:    t52 = (t39 + 4);
    *((unsigned int *)t39) = 1;
    *((unsigned int *)t52) = 1;
    goto LAB31;

LAB32:    t57 = (t0 + 2008U);
    t58 = *((char **)t57);
    t57 = ((char*)((ng3)));
    memset(t59, 0, 8);
    xsi_vlog_unsigned_minus(t59, 32, t58, 2, t57, 32);
    goto LAB33;

LAB34:    t64 = ((char*)((ng2)));
    goto LAB35;

LAB36:    xsi_vlog_unsigned_bit_combine(t38, 32, t59, 32, t64, 32);
    goto LAB40;

LAB38:    memcpy(t38, t59, 8);
    goto LAB40;

}


extern void work_m_00000000002385470442_3543545313_init()
{
	static char *pe[] = {(void *)Always_39_0};
	xsi_register_didat("work_m_00000000002385470442_3543545313", "isim/mips_tb_isim_beh.exe.sim/work/m_00000000002385470442_3543545313.didat");
	xsi_register_executes(pe);
}
